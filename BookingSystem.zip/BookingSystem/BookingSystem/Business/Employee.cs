﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookingSystem.Business
{
    public class Employee
    {
        #region Data members
        private int employeeID;
        private string employeeName;
        private int employeeAge;
        // WHat is shift??? 
        // We need more for this but even more so Why do we need an employee class??
        #endregion

        #region Property methods

        #endregion

        #region Constructors
        public Employee()
        {

        }
        #endregion


    }
}
